module.exports = {
    'secret': 'supersecret'
};