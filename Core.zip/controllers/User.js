const logger = require('../config/logger')
const  db=require('../config/db.config')
const User = db.users;

// Add a user
const Add =(request, response) => {  
    var p_login= request.body.login;  
    var p_name = request.body.name;  
    var p_email = request.body.email;  
    var p_password = request.body.password;  
    var p_mobile = request.body.mobile ; 
    var p_entry_user=request.body.entry_user ;
    var p_edit_user= request.body.edit_user;
    var p_role=request.body.role;
    var p_module_set=request.body.module_set;
    
    db.sequelize.query('SELECT * FROM ctl_user_add(:login , :name , :email ,:password, :mobile  , :entry_user , :edit_user , :role , :module_set ) ',

           { replacements: { login: p_login, name: p_name,email: p_email, password:p_password, mobile: p_mobile,entry_user:p_entry_user,edit_user:p_edit_user,role:p_role,module_set:p_module_set}, type: db.sequelize.QueryTypes.SELECT }
           , {
                model: User,
                mapToModel: true // pass true here if you have any mapped fields
        }).then(User => {
            logger.info(User)
            response.json(User)
        }).catch(err => {
                logger.error(err)
                response.status(500).json({msg: "error", details: err});
            });
   
};


 // FETCH by citeria
 const ViewByCriteria = (request, response) => {
    var p_role = request.body.role ;    
    var p_keyword = request.body.p_keyword;    
    db.sequelize.query('SELECT * FROM ctl_user_viewbycriteria(:p_keyword,:role) ',

            { replacements: {  role: p_role,p_keyword:p_keyword}, type: db.sequelize.QueryTypes.SELECT }
            ,{
                model: User,
                mapToModel: true // pass true here if you have any mapped fields
        }).then(User => {
            logger.info(User)
            response.json(User)
        }).catch(err => {
                logger.error(err)
                response.status(500).json({msg: "error", details: err});
            });
    
};

// Update by login
const Update =(request, response) => { 
    var p_login= request.body.login;  
    var p_name = request.body.name;  
    var p_email = request.body.email;  
    var p_password = request.body.password;  
    var p_mobile = request.body.mobile ; 
    var p_entry_user=request.body.entry_user ;
    var p_edit_user= request.body.edit_user;
    var p_role=request.body.role;
    var p_module_set=request.body.module_set;
    
    db.sequelize.query('SELECT * FROM ctl_user_add(:login , :name , :email ,:password, :mobile  , :entry_user , :edit_user , :role , :module_set ) ',

           { replacements: { login: p_login, name: p_name,email: p_email, password:p_password, mobile: p_mobile,entry_user:p_entry_user,edit_user:p_edit_user,role:p_role,module_set:p_module_set}, type: db.sequelize.QueryTypes.SELECT }
           , {
                model: User,
                mapToModel: true // pass true here if you have any mapped fields
        }).then(User => {
            logger.info(User)
            response.json(User)
        }).catch(err => {
                logger.error(err)
                response.status(500).json({msg: "error", details: err});
            });
   
};
const Authenticate =(request, response) => { 
    var p_login= request.body.login;  
    var p_password =request.body.password
    
    db.sequelize.query('SELECT * FROM ctl_user_authenticate(:login,:password) ',

           { replacements: { login: p_login, password:p_password}, type: db.sequelize.QueryTypes.SELECT }
           , {
                model: User,
                mapToModel: true // pass true here if you have any mapped fields
        }).then(User => {
            logger.info(User)
            response.json(User)
        }).catch(err => {
                logger.error(err)
                response.status(500).json({msg: "error", details: err});
            });
   
};



module.exports = {
    Add,
    ViewByCriteria,
    Update,
    Authenticate


    

}