module.exports = function(db, sequelize, Sequelize) {

}