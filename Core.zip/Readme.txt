Edit by Fehmi:
*npm install --save sequelize
*npm install --save sequelize-cli
*npm install --save pg pg-hstore
*npm install jsonwebtoken
*npm install bcrypt-nodejs
*npm install cors
*npm install dotenv
*npm install passport
*npm install passport-google-oauth
*npm install passport-facebook
*npm install passport-twitter

Nessrine
*npm i winston --save
*npm i app-root-path --save
npm i morgan --save
