module.exports = function(app) {
    const typeApplication = require('../controllers/TypeApplication');

    // View all typeApplications
    app.get('/core/typeApplication', typeApplication.View);

}