module.exports = function(app) {
    const typeAuthentication = require('../controllers/TypeAuthentication');

    // View all typeAuthentications
    app.get('/core/typeAuthentication', typeAuthentication.View);

    // Update a typeAuthentication with Status   
    app.put('/core/typeAuthentication/status/', typeAuthentication.Status);
    /*
    {
	
	"id_type_auth":2
    }
    */
}

