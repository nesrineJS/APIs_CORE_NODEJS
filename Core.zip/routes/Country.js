/*******************************FETCH ALL THE COUNTRIES*********************************/
module.exports = function(app) {
    const country = require('../controllers/Country.js'); 
    
    //VIEW ALL COUNTRIES
    app.get('/core/country', country.View);



    app.put('/core/country/viewbycountry/', country.ViewByCountry);

    /*{
        "id_developer":"80"
    }*/


    app.put('/core/country/viewdevpbycountry/', country.ViewDevByCountry);

    /*{
    "p_keyword": ""
    "id_developer":"80",
    "id_app":"", 
    "id_api":"", 
    "id_app_api":"", 
    "dlr_type":"",
    "prefix":"", 
    "id_country":"", 
    "status":"", 
    "p_begin_date":, 
    "p_end_date":"
    }*/


}