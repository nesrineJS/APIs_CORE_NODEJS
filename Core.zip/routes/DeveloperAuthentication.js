module.exports = function(app) {
    const developerAuthentication = require('../controllers/DeveloperAuthentication');
    

// Update a developerAuthentication'status   
app.put('/core/developerauthentication/status/', developerAuthentication.Status);
/*
{
 "id_developer":"", 
 "id_type_auth":"" 
}
*/

// Add a developerAuthentication
app.put('/core/developerauthentication/add/', developerAuthentication.Add);
/*
{
    "id_developer":"",
    "id_type_auth":"",
    "last_date":"",
    "email":"",
    "mobile":"",
    "uid":"",
    "token":"",
    "param1":"",
    "param2":""
}
*/



// Add a developerAuthentication by social
    app.put('/core/developerauthentication/add/social', developerAuthentication.AddSocial);

    //verif authentication by id_developer and token
    app.put('/core/developerauthentication/token', developerAuthentication.ChekToken);
    // check authentication from social
    app.put('/core/developerauthentication/checkAutentication', developerAuthentication.ChekSocial);

}