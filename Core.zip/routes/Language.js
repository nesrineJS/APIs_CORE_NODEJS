module.exports = function(app) {
    const language = require('../controllers/Language');

    // View all languages
    app.get('/core/language', language.View);

    // Add a language    
    app.put('/core/language/add/', language.Add);
    /*
    {
	"id_language":"ruby",
	"label":"rubyonrails",
	"description":"frameworkrubyonrails"
    }
    */

    // Update a language with Status   
    app.put('/core/language/status/', language.Status);
    /*
    {
	"id_language":"php"
    }
    */
}

