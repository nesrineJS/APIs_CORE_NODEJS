module.exports = function(app) {
    const user = require('../controllers/User');   
     //---------------- add a user---------------------------
    /* {
        "login": "amal",
        "name":"amal",
        "email": "ghali",
        "password": "fr",
        "mobile": "21698607512",
        "entry_user": "admin",
        "edit_user": "admin",
        "role": "dev",
        "module_set": ";16;"
    }*/
     app.put('/core/user/add',user.Add);
     //---------------- fetch bu cireteria--------------------
     /* {
        "p_keyword": "adm",
        "role": ""
    }
     */
     app.put('/core/user/criteria', user.ViewByCriteria);
     //----------update by  login------------------------------
       /* {
        "login": "amal",
        "name":"amal",
        "email": "ghali",
        "password": "fr",
        "mobile": "21698607512",
        "entry_user": "admin",
        "edit_user": "dev",
        "role": "dev",
        "module_set": ";16;"
    }
       */
     app.put('/core/user/update', user.Update);
     //----------- Authenticate---------------------------
     /* {
        "login": "amal",
        "password": "fr"
    }
     */
     app.put('/core/user/authentication', user.Authenticate);

    

}
